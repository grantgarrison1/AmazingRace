from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('home/', views.home, name='home'),
    path('team/<int:team_id>/', views.team_details, name='team_details'),
    path('submit_picture/<int:participant_id>/<int:riddle_id>/', views.submit_picture, name='submit_picture'),
    path('leaderboard/', views.leaderboard, name='leaderboard'),
    path('team_timer/<int:team_id>/', views.team_timer, name='team_timer'),
    path('riddle_complete/<int:participant_id>/<int:riddle_id>/', views.riddle_complete, name='riddle_complete'),
    path('submit_riddle_answer/<int:participant_id>/<int:riddle_id>/', views.submit_riddle_answer, name='submit_riddle_answer'),
    path('assign_riddles/<int:team_id>/', views.assign_riddles, name='assign_riddles'),
    path('register_team/', views.register_team, name='register_team'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
]
