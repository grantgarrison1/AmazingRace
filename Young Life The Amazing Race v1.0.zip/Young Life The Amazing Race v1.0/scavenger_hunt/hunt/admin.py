from django.contrib import admin
from .models import Clue, UserProgress, Team, TeamMember

admin.site.register(Clue)
admin.site.register(UserProgress)
admin.site.register(Team)
admin.site.register(TeamMember)
