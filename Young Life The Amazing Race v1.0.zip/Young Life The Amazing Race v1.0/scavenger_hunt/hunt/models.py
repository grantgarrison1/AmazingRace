from django.db import models

class Participant(models.Model):
    name = models.CharField(max_length=255)
    team = models.ForeignKey('Team', on_delete=models.CASCADE, related_name="participants")
    start_time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Team(models.Model):
    name = models.CharField(max_length=255)
    progress = models.IntegerField(default=0)
    start_time = models.DateTimeField(auto_now_add=True)
    submissions = models.IntegerField(default=0)
    score = models.IntegerField(default=0)

    def __str__(self):
        return self.name

class Clue(models.Model):
    question = models.TextField(default="Default question")
    answer = models.CharField(max_length=255)
    points = models.PositiveIntegerField()

class TeamMember(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="team_members")  
    participant = models.ForeignKey(Participant, null=True, on_delete=models.CASCADE)

    role = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.participant.name} - {self.role}"

class Riddle(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    question = models.TextField()
    answer = models.CharField(max_length=200)
    points = models.IntegerField(default=10)
    sequence = models.IntegerField()

    def __str__(self):
        return f"Riddle {self.sequence}: {self.question[:50]}"

class Submission(models.Model):
    participant = models.ForeignKey(Participant, on_delete=models.CASCADE, related_name="submissions")
    riddle = models.ForeignKey(Riddle, on_delete=models.CASCADE, related_name="submissions")
    attempt = models.IntegerField(default=0)
    is_correct = models.BooleanField(default=False)
    picture = models.ImageField(upload_to='pictures/', blank=True, null=True)

    def __str__(self):
        status = "Correct" if self.is_correct else "Incorrect"
        return f"Submission by {self.participant.name} for Riddle {self.riddle.sequence}: {status}"

class UserProgress(models.Model):
    participant = models.ForeignKey(Participant, null=True, on_delete=models.CASCADE, related_name="progress")
    riddle = models.ForeignKey(Riddle, null=True, on_delete=models.CASCADE, related_name="progress")
    points_earned = models.IntegerField(default=0)
    time_taken = models.FloatField(default=0.0)
    completed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.participant.name} - Riddle {self.riddle.sequence} Progress"
