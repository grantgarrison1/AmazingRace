from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.http import HttpResponse
from .forms import CustomUserCreationForm
from .models import Team, Participant, Riddle

def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
    else:
        form = AuthenticationForm()
    
    return render(request, 'login.html', {'form': form})

def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = CustomUserCreationForm()
    
    return render(request, 'register.html', {'form': form})

def home(request):
    if not request.user.is_authenticated:
        return redirect('login')

    teams = Team.objects.all()
    return render(request, 'home.html', {'teams': teams})

def team_details(request, team_id):
    try:
        team = Team.objects.get(id=team_id)
        participants = team.participants.all()
        return render(request, 'team_details.html', {'team': team, 'participants': participants})
    except Team.DoesNotExist:
        return HttpResponse("Team not found.", status=404)

def submit_picture(request, participant_id, riddle_id):
    try:
        participant = Participant.objects.get(id=participant_id)
        riddle = Riddle.objects.get(id=riddle_id)
        return HttpResponse("Picture submitted successfully!")
    except Participant.DoesNotExist or Riddle.DoesNotExist:
        return HttpResponse("Participant or Riddle not found.", status=404)

def leaderboard(request):
    teams = Team.objects.all().order_by('-score')
    return render(request, 'leaderboard.html', {'teams': teams})

def team_timer(request, team_id):
    try:
        team = Team.objects.get(id=team_id)
        remaining_time = 3600
        return render(request, 'team_timer.html', {'team': team, 'remaining_time': remaining_time})
    except Team.DoesNotExist:
        return HttpResponse("Team not found.", status=404)

def riddle_complete(request, participant_id, riddle_id):
    try:
        participant = Participant.objects.get(id=participant_id)
        riddle = Riddle.objects.get(id=riddle_id)
        riddle.completed = True
        riddle.save()
        return HttpResponse(f"Riddle {riddle_id} completed successfully!")
    except Participant.DoesNotExist or Riddle.DoesNotExist:
        return HttpResponse("Participant or Riddle not found.", status=404)

def submit_riddle_answer(request, participant_id, riddle_id):
    try:
        participant = Participant.objects.get(id=participant_id)
        riddle = Riddle.objects.get(id=riddle_id)
        answer = request.POST.get('answer')

        if answer.lower() == riddle.correct_answer.lower():
            riddle.completed = True
            riddle.save()
            return HttpResponse(f"Correct answer for Riddle {riddle_id}!")
        else:
            return HttpResponse("Incorrect answer. Try again!", status=400)
    except Participant.DoesNotExist or Riddle.DoesNotExist:
        return HttpResponse("Participant or Riddle not found.", status=404)

def assign_riddles(request, team_id):
    try:
        team = Team.objects.get(id=team_id)
        riddles = Riddle.objects.filter(team=team).order_by('sequence')
        return HttpResponse(f"Riddles assigned to Team {team_id}!")
    except Team.DoesNotExist:
        return HttpResponse("Team not found.", status=404)

def register_team(request):
    if request.method == 'POST':
        team_name = request.POST.get('team_name')
        member_names = request.POST.getlist('member_names')

        team = Team.objects.create(name=team_name)

        for member_name in member_names:
            Participant.objects.create(name=member_name, team=team)

        return redirect('home')
    else:
        return render(request, 'register_team.html')

def logout_view(request):
    logout(request)
    return redirect('login')


